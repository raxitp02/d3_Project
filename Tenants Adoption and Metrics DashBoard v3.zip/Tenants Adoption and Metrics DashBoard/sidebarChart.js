var margin = {top: 25, right: 75, bottom: 85, left: 85},
        w = 400 - margin.left - margin.right,
        h = 280 - margin.top - margin.bottom;
var padding = 10;

var colors =  [["Apps", "#377EB8"],
         ["Agents_Using_Platform", "#4DAF4A"]];

var dataset = [
   {
      "Launch_TimeFrame":"Jun-13",
      "Channel":"Banca",
      "GSP":"Russia",
      "Program_to_Launch_TimeFrame":"345672",
      "Quotes":"3377",
      "Apps":"1658",
      "Quote_to_App_Conversion_Rate":"49",
      "Issued_Premium_USD":"22,000",
      "Agents_Using_Platform":"142.95"
   },
   {
      "Launch_TimeFrame":"Jun-13",
      "Channel":"DTC",
      "GSP":"USSD",
      "Program_to_Launch_TimeFrame":"195861",
      "Quotes":"2498",
      "Apps":"1943",
      "Quote_to_App_Conversion_Rate":"78",
      "Issued_Premium_USD":"21,000",
      "Agents_Using_Platform":"305"
   },
   {
      "Launch_TimeFrame":"Aug-14",
      "Channel":"Agency",
      "GSP":"Columbia",
      "Program_to_Launch_TimeFrame":"521077",
      "Quotes":"1731.8",
      "Apps":"1330",
      "Quote_to_App_Conversion_Rate":"8",
      "Issued_Premium_USD":"4,000,000",
      "Agents_Using_Platform":"2223"
   },
   {
      "Launch_TimeFrame":"Nov-14",
      "Channel":"Banca",
      "GSP":"Vietnam",
      "Program_to_Launch_TimeFrame":"72754",
      "Quotes":"1871",
      "Apps":"194",
      "Quote_to_App_Conversion_Rate":"10",
      "Issued_Premium_USD":"0",
      "Agents_Using_Platform":"3058"
   },
   {
      "Launch_TimeFrame":"Oct-14",
      "Channel":"DTC",
      "GSP":"China-ADD",
      "Program_to_Launch_TimeFrame":"9264",
      "Quotes":"531",
      "Apps":"20",
      "Quote_to_App_Conversion_Rate":"4",
      "Issued_Premium_USD":"5,000",
      "Agents_Using_Platform":""
   },
   {
      "Launch_TimeFrame":"Aug-15",
      "Channel":"Group",
      "GSP":"CAT",
      "Program_to_Launch_TimeFrame":"507",
      "Quotes":"419",
      "Apps":"88",
      "Quote_to_App_Conversion_Rate":"21",
      "Issued_Premium_USD":"0",
      "Agents_Using_Platform":"4640"
   },
   {
      "Launch_TimeFrame":"May-16",
      "Channel":"Group",
      "GSP":"Banca Gulf",
      "Program_to_Launch_TimeFrame":"235",
      "Quotes":"14",
      "Apps":"7",
      "Quote_to_App_Conversion_Rate":"50",
      "Issued_Premium_USD":"0",
      "Agents_Using_Platform":"40"
   }
];

var xScale = d3.scale.ordinal()
        .domain(d3.range(dataset.length))
        .rangeRoundBands([0, w], 0.05); 
// ternary operator to determine if Agents_Using_Platform or Apps has a larger scale
var yScale = d3.scale.linear()
        .domain([0, d3.max(dataset, function(d) { return (d.Apps > d.Program_to_Launch_TimeFrame) ? d.Apps : d.Program_to_Launch_TimeFrame;})]) 
        .range([h, 0]);
var xAxis = d3.svg.axis()
        .scale(xScale)
        .tickFormat(function(d) { return dataset[d].GSP; })
        .orient("bottom");
var yAxis = d3.svg.axis()
        .scale(yScale)
        .orient("left")
        .ticks(5);

var commaFormat = d3.format(',');

//SVG element
var svg = d3.select("#searchVolume")
      .append("svg")
      .attr("width", w + margin.left + margin.right)
      .attr("height", h + margin.top + margin.bottom)
      .append("g")
      .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
  
// Graph Bars
var sets = svg.selectAll(".set") 
  .data(dataset) 
  .enter()
  .append("g")
    .attr("class","set")
    .attr("transform",function(d,i){
         return "translate(" + xScale(i) + ",0)";
     }) ;

sets.append("rect")
    .attr("class","Apps")
  .attr("width", xScale.rangeBand()/2)
  .attr("y", function(d) {
    return yScale(d.Apps);
  })
    .attr("x", xScale.rangeBand()/2)
    .attr("height", function(d){
        return h - yScale(d.Apps);
    })
  .attr("fill", colors[0][1])
  .on("mouseover", function(d,i) {
    //Get this bar's x/y values, then augment for the tooltip
    var xPosition = parseFloat(xScale(i) + xScale.rangeBand() );
    var yPosition = h / 2;
    //UpLaunch_TimeFrame Tooltip Position & value
    d3.select("#tooltip")
      .style("left", xPosition + "px")
      .style("top", yPosition + "px")
      .select("#QuotesVal")
      .text(d.Quotes);
    d3.select("#tooltip")
      .select("#volVal")
      .text(commaFormat(d.Apps));
    d3.select("#tooltip")
      .select("#GSP")
      .style("color", colors[1][1])
      .text(d.GSP);
    d3.select("#tooltip").classed("hidden", false);
  })
  .on("mouseout", function() {
    //Remove the tooltip
    d3.select("#tooltip").classed("hidden", true);
  })
    ;

sets.append("rect")
    .attr("class","Agents_Using_Platform")
  .attr("width", xScale.rangeBand()/2)
  .attr("y", function(d) {
    return yScale(d.Agents_Using_Platform);
  })
    .attr("height", function(d){
        return h - yScale(d.Agents_Using_Platform);
    })
  .attr("fill", colors[1][1])
  .on("mouseover", function(d,i) {
    //Get this bar's x/y values, then augment for the tooltip
    var xPosition = parseFloat(xScale(i) + xScale.rangeBand() );
    var yPosition = h / 2;
    //UpLaunch_TimeFrame Tooltip Position & value
    d3.select("#tooltip")
      .style("left", xPosition + "px")
      .style("top", yPosition + "px")
      .select("#QuotesVal")
      .text(d.Quotes);
    d3.select("#tooltip")
      .select("#volVal")
      .text(commaFormat(d.Agents_Using_Platform));
    d3.select("#tooltip")
      .select("#GSP")
      .style("color", colors[1][1])
      .text(d.GSP);
    d3.select("#tooltip").classed("hidden", false);
  })
  .on("mouseout", function() {
    //Remove the tooltip
    d3.select("#tooltip").classed("hidden", true);
  })
  ;
  
// Labels
sets.append("text")
  .attr("class", "Apps")
  .attr("width", xScale.rangeBand()/2)
  .attr("y", function(d) {
    return yScale(d.Apps);
    })
    .attr("dy", 10)
    .attr("dx", (xScale.rangeBand()/1.60) )
//  .attr("text-anchor", "middle")
    .attr("font-family", "sans-serif") 
    .attr("font-size", "8px")
    .attr("fill", "white")
  .text(function(d) {
    return commaFormat(d.Apps);
    });   
  
sets.append("text")
  .attr("class", "Agents_Using_Platform")
  .attr("y", function(d) {
    return yScale(d.Agents_Using_Platform);
    })
    .attr("dy", 10)
    .attr("dx",(xScale.rangeBand() / 4) - 10)
//  .attr("text-anchor", "middle")
    .attr("font-family", "sans-serif") 
    .attr("font-size", "8px")
    .attr("fill", "white")
  .text(function(d) {
    return commaFormat(d.Agents_Using_Platform);
    });

// xAxis
svg.append("g") // Add the X Axis
  .attr("class", "x axis")
  .attr("transform", "translate(0," + (h) + ")")
  .call(xAxis)
  .selectAll("text")
    .style("text-anchor", "end")
    .attr("dx", "-.8em")
    .attr("dy", ".15em")
    .attr("transform", function(d) {
        return "rotate(-25)";
    })
    ;
// yAxis
svg.append("g")
  .attr("class", "y axis")
  .attr("transform", "translate(0 ,0)")
  .call(yAxis)
  ;
// xAxis label
svg.append("text") 
  .attr("transform", "translate(" + (w / 2) + " ," + (h + margin.bottom - 5) +")")
  .style("text-anchor", "middle")
  .text("GSP");
//yAxis label
svg.append("text")
    .attr("transform", "rotate(-90)")
    .attr("y", 0 - margin.left)
    .attr("x", 0 - (h / 2))
    .attr("dy", "1em")
    .style("text-anchor", "middle")
    .text("# of Searches");

// Title
svg.append("text")
    .attr("x", (w / 2))
    .attr("y", 0 - (margin.top / 2))
    .attr("text-anchor", "middle")
    .style("font-size", "16px")
    .style("text-decoration", "underline")
    .text("Agents_Using_Platform & Apps Searches");

// add legend   
var legend = svg.append("g")
    .attr("class", "legend")
//    .attr("x", w - 65)
//    .attr("y", 50)
//    .attr("height", 100)
//    .attr("width", 100)
    .attr("transform", "translate(70,10)")
    ;
var legendRect = legend.selectAll('rect').data(colors);

legendRect.enter()
    .append("rect")
    .attr("x", w - 65)
//  .attr("y", 0)                   // use this to flip horizontal
    .attr("width", 10)
    .attr("height", 10)
    .attr("y", function(d, i) {
        return i * 20;
    })
//  .attr("x", function(d, i){return w - 65 - i * 70}) // use this to flip horizontal
    .style("fill", function(d) {
        return d[1];
    });

var legendText = legend.selectAll('text').data(colors);

legendText.enter()
    .append("text")
    .attr("x", w - 52)
    .attr("y", function(d, i) {
        return i * 20 + 9;
    })
    .text(function(d) {
        return d[0];
    });

function upLaunch_TimeFrameBars()
{ 
    svg.selectAll(".Apps").remove();
  svg.selectAll(".Agents_Using_Platform").transition().duration(500).attr("width", xScale.rangeBand());
}
d3.select("#change").on("click", upLaunch_TimeFrameBars);




var data = [
   {
      "Launch_TimeFrame":"Jun-13",
      "Channel":"Banca",
      "GSP":"Russia",
      "Program_to_Launch_TimeFrame":"345672",
      "Quotes":"3377",
      "Apps":"1658",
      "Quote_to_App_Conversion_Rate":"49",
      "Issued_Premium_USD":"22,000",
      "Agents_Using_Platform":"142.95"
   },
   {
      "Launch_TimeFrame":"Jun-13",
      "Channel":"DTC",
      "GSP":"USSD",
      "Program_to_Launch_TimeFrame":"195861",
      "Quotes":"2498",
      "Apps":"1943",
      "Quote_to_App_Conversion_Rate":"78",
      "Issued_Premium_USD":"21,000",
      "Agents_Using_Platform":"305"
   },
   {
      "Launch_TimeFrame":"Aug-14",
      "Channel":"Agency",
      "GSP":"Columbia",
      "Program_to_Launch_TimeFrame":"521077",
      "Quotes":"1731.8",
      "Apps":"1330",
      "Quote_to_App_Conversion_Rate":"8",
      "Issued_Premium_USD":"4,000,000",
      "Agents_Using_Platform":"2223"
   },
   {
      "Launch_TimeFrame":"Nov-14",
      "Channel":"Banca",
      "GSP":"Vietnam",
      "Program_to_Launch_TimeFrame":"72754",
      "Quotes":"1871",
      "Apps":"194",
      "Quote_to_App_Conversion_Rate":"10",
      "Issued_Premium_USD":"0",
      "Agents_Using_Platform":"3058"
   },
   {
      "Launch_TimeFrame":"Oct-14",
      "Channel":"DTC",
      "GSP":"China-ADD",
      "Program_to_Launch_TimeFrame":"9264",
      "Quotes":"531",
      "Apps":"20",
      "Quote_to_App_Conversion_Rate":"4",
      "Issued_Premium_USD":"5,000",
      "Agents_Using_Platform":""
   },
   {
      "Launch_TimeFrame":"Aug-15",
      "Channel":"Group",
      "GSP":"CAT",
      "Program_to_Launch_TimeFrame":"507",
      "Quotes":"419",
      "Apps":"88",
      "Quote_to_App_Conversion_Rate":"21",
      "Issued_Premium_USD":"0",
      "Agents_Using_Platform":"4640"
   },
   {
      "Launch_TimeFrame":"May-16",
      "Channel":"Group",
      "GSP":"Banca Gulf",
      "Program_to_Launch_TimeFrame":"235",
      "Quotes":"14",
      "Apps":"7",
      "Quote_to_App_Conversion_Rate":"50",
      "Issued_Premium_USD":"0",
      "Agents_Using_Platform":"40"
   }
];
function OilChart(container){
    this.container = container;
    this.isInit = false;
}
OilChart.prototype.draw = function(data) {
    if(this.isInit)
        this.redraw(data);
    else
        this.init(data);
};
OilChart.prototype.redraw = function(data){

};
OilChart.prototype.init = function(data){
    var that = this;
    //计算盒模型
    this.boxModal ={};
    this.boxModal.paddingLeft = 40;
    this.boxModal.paddingRight = 20;
    this.boxModal.paddingTop = 20;
    this.boxModal.paddingBottom = 30;
    this.boxModal.width = this.container.clientWidth - this.boxModal.paddingLeft - this.boxModal.paddingRight;
    this.boxModal.height = this.container.clientHeight - this.boxModal.paddingTop - this.boxModal.paddingBottom;
    //初始化 svg 容器
    this.svg = d3.select(this.container)
        .append('svg')
        .attr('width', this.container.clientWidth)
        .attr('height', this.container.clientHeight)
        .attr('xmlns','http://www.w3.org/2000/svg')
        .attr('version','1.1')
        .attr('viewBox','0,0,'+this.container.clientWidth+','+this.container.clientHeight)
        .attr('preserveAspectRatio','none');

    //x-axis 比例尺
    this.xScale = d3.scale.linear()
        .domain([0, data.length-1])
        .range([0, this.boxModal.width]);
    //y-axis 比例尺
    this.yScale = d3.scale.linear()
        .domain([0, 100*d3.max(data.map(function(item){return item.Apps;}))])
        .range([0,this.boxModal.height]);

    //y-axis 绘制 比例尺
    this.yAxisScale = d3.scale.linear()
        .domain([100*d3.max(data.map(function(item){return item.Apps;})),0])
        .range([0,this.boxModal.height]);

    //x-axis 绘制
    var xAxis = d3.svg.axis()
        .orient('bottom')
        .scale(this.xScale)
        .tickFormat(function(d){
            var tick = '';
            if(d == parseInt(d) && data[d] !== undefined)
                tick = data[d].Launch_TimeFrame;
            return tick;
        });
    //y-axis 绘制
    var yAxis = d3.svg.axis()
        .orient('left')
        .scale(this.yAxisScale);
    //绘制 x 坐标轴
    this.xAxisGraph = this.svg.append('g')
        .attr('class', 'x-axis')
        .attr('transform','translate('+this.boxModal.paddingLeft+','+(this.boxModal.height+this.boxModal.paddingTop)+')')
        .call(xAxis);
    //绘制 y 坐标轴
    this.yAxisGraph = this.svg.append('g')
        .attr('class','y-axis')
        .attr('transform','translate('+this.boxModal.paddingLeft+','+(this.boxModal.paddingTop)+')')
        .call(yAxis);

    //y-axis 刻度延长线容器
    this.yTickLengthenWrap = this.svg.append('g')
        .attr('class','y-lengthen-wrapper')
        .attr('transform','translate('+this.boxModal.paddingLeft+','+(this.boxModal.paddingTop)+')');
    //绘制 y-axis 刻度延长线
    this.yTickLengthenWrap.selectAll('.y-lengthen')
        .data(that.yAxisScale.ticks())
        .enter()
        .append('line')
        .attr('class','y-lengthen')
        .attr('x1', 0)
        .attr('x2', this.boxModal.width)
        .attr('y1', function (d) {
            return that.yAxisScale(d)
        })
        .attr('y2', function (d) {
            return that.yAxisScale(d)
        });

    //defs 定义元素
    this.defs = this.svg.append('defs');
    //定义渐变
    this.linearGradient = this.defs.append('linearGradient').attr('id','gradient');
    this.linearGradient
        .attr('x1',0)
        .attr('x2',0)
        .attr('y1',0)
        .attr('y2',1)
        .selectAll('stop')
        .data([{offset:0,stopColor:'#058ee8',opacity:1},
            {offset:100,stopColor:'#058ee8',opacity:0}])
        .enter()
        .append('stop')
        .attr('offset',function(d){return d.offset+'%';})
        .attr('stop-color',function(d){return d.stopColor;})
        .attr('stop-opacity',function(d){return d.opacity;});

    //绘制渐变路径
    this.gradientPath = this.svg.append('path')
        .attr('fill','url(#gradient)')
        .attr('transform','translate('+this.boxModal.paddingLeft+','+(this.boxModal.paddingTop)+')')
        .attr('d',function(){
            if(data.length < 2) return '';
            var pathCommand = [];
            var path = '';
            for(var maxIndex = data.length - 1,i=0 ; i<=maxIndex; i++){
                pathCommand.push({
                    x: that.xScale(i),
                    y: that.yAxisScale(data[i]['Apps'])
                });
            }
            pathCommand.unshift({
                x:that.xScale(0),
                y:that.yAxisScale(0)
            });
            pathCommand.push({
                x:that.xScale(data.length-1),
                y:that.yAxisScale(0)
            });
            console.log(pathCommand)
            path += 'M '+pathCommand[0]['x']+' '+pathCommand[0]['y']+'\n';
            pathCommand.forEach(function(elem){
                path+= 'L '+elem['x']+' '+elem['y']+'\n';
            });
            path +='L '+pathCommand[0]['x']+' '+pathCommand[0]['y'];
            return path;
        });

    //折线容器
    this.linesWrap = this.svg.append('g')
        .attr('class','lines-wrapper')
        .attr('transform','translate('+this.boxModal.paddingLeft+','+(this.boxModal.paddingTop)+')');

    //绘制线
    this.linesWrap.selectAll('.line')
        .data(data)
        .enter()
        .append('line')
        .attr('class','line')
        .attr('x1',function(d,i){
            if(i===0) return 0;
            return that.xScale(i-1);
        })
        .attr('y1',function(d,i){
            if(i===0) return 0;
            var nextData = data[i-1]
            return that.boxModal.height - that.yScale(nextData.Apps);
        })
        .attr('x2',function(d,i){
            if(i===0) return 0;
            return that.xScale(i)
        })
        .attr('y2',function(d,i){
            if(i===0) return 0;
            return that.boxModal.height -that.yScale(d.Apps);
        });

    //点容器
    this.pointsWrap = this.svg.append('g')
        .attr('class','points-wrapper')
        .attr('transform','translate('+this.boxModal.paddingLeft+','+(this.boxModal.paddingTop)+')');

    //绘制点
    this.pointsWrap.selectAll('.point')
        .data(data)
        .enter()
        .append('circle')
        .attr('class','point')
        .attr('r','3')
        .attr('cx',function(d,i){return that.xScale(i)})
        .attr('cy',function (d,i){return that.boxModal.height - that.yScale(d.Apps)});

    //x-axis 单位容器
    this.xAxisUnitWrap = this.svg.append('g')
        .attr('class','x-axis-unit-wrapper')
        .attr('transform','translate('+(this.boxModal.width+this.boxModal.paddingLeft)+','+(this.boxModal.height+this.boxModal.paddingTop-4)+')');
    //绘制 y-axis 单位
    this.xAxisUnitWrap.append('text')
        .attr('class','x-axis-unit')
        .attr('text-anchor','end')
        .text('日期');

    //y-axis 单位容器
    this.yAxisUnitWrap = this.svg.append('g')
        .attr('class','y-axis-unit-wrapper')
        .attr('transform','translate(10,15)');
    //绘制 y-axis 单位
    this.yAxisUnitWrap.append('text')
        .attr('class','y-axis-unit')
        .text('今日油耗（L）');

    //触控区域 容器
    this.touchWrap = this.svg.append('g')
        .attr('class','touch-wrapper')
        .attr('transform','translate('+this.boxModal.paddingLeft+','+(this.boxModal.paddingTop)+')');

    //添加提示框
    this.tooltip = d3.select('body').append('div').attr('class','tooltip');
    this.tooltip.append('p').attr('class','Launch_TimeFrame');
    this.tooltip.append('p').attr('class','oil');

    //触控点绘制
    this.touchWrap.selectAll('.touch-point')
        .data(data)
        .enter()
        .append('circle')
        .attr('class','touch-point')
        .attr('r','16')
        .attr('cx',function(d,i){return that.xScale(i)})
        .attr('cy',function (d,i){return that.boxModal.height - that.yScale(d.Apps)})
        .on('click',function(d,i){
            d3.event.stopPropagation();
            d3.event.preventDefault();
            var offsetX = 0;
            var offsetY = 0;
            if(d3.max(that.xScale.domain())  == i ) offsetX = -25;
            if(d3.max(that.yScale.domain())/2 >= d.Apps ) offsetY = -50;
            that.tooltip.attr('class','tooltip active');
            that.tooltip.style("left", (d3.event.pageX+offsetX) + "px")
                .style("top", (d3.event.pageY+offsetY) + "px");
            that.tooltip.select('.Launch_TimeFrame').text('日期：'+ d.Launch_TimeFrame);
            that.tooltip.select('.oil').text('油耗：'+ d.Apps);
        });
    // 触摸 svg
    this.svg.on('click',function(){
        that.tooltip.attr('class','tooltip');
    });
};
var chart = new OilChart(document.querySelector('.chart'));
chart.draw(data);
//<base> url 重定义 bug
chart.gradientPath.attr('fill','url('+location.href+'#gradient)');