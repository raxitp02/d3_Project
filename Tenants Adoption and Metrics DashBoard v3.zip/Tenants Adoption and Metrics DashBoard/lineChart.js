var dataset = {
  title: "Horizontal BarGraph",
  data: [{
    "Launch_TimeFrame": "Jun-13",
    "Channel": "Banca",
    "GSP": "Russia",
    "Program_to_Date": "345672",
    "Quotes": "3377",
    "Apps": "1658",
    "Quote_to_App_Conversion_Rate": "49",
    "Issued_Premium_USD": "22,000",
    "Agents_Using_Platform": "14295"
}, {
    "Launch_TimeFrame": "Jun-13",
    "Channel": "DTC",
    "GSP": "USSD",
    "Program_to_Date": "195861",
    "Quotes": "2498",
    "Apps": "1943",
    "Quote_to_App_Conversion_Rate": "78",
    "Issued_Premium_USD": "21,000",
    "Agents_Using_Platform": "305"
}, {
    "Launch_TimeFrame": "Aug-14",
    "Channel": "Agency",
    "GSP": "Columbia",
    "Program_to_Date": "521077",
    "Quotes": "17318",
    "Apps": "1330",
    "Quote_to_App_Conversion_Rate": "8",
    "Issued_Premium_USD": "4,000,000",
    "Agents_Using_Platform": "2223"
}, {
    "Launch_TimeFrame": "Nov-14",
    "Channel": "Banca",
    "GSP": "Vietnam",
    "Program_to_Date": "72754",
    "Quotes": "1871",
    "Apps": "194",
    "Quote_to_App_Conversion_Rate": "10",
    "Issued_Premium_USD": "0",
    "Agents_Using_Platform": "3058"
}, {
    "Launch_TimeFrame": "Oct-14",
    "Channel": "DTC",
    "GSP": "ChinaADD",
    "Program_to_Date": "9264",
    "Quotes": "531",
    "Apps": "20",
    "Quote_to_App_Conversion_Rate": "4",
    "Issued_Premium_USD": "5,000",
    "Agents_Using_Platform": ""
}, {
    "Launch_TimeFrame": "Aug-15",
    "Channel": "Group",
    "GSP": "CAT",
    "Program_to_Date": "507",
    "Quotes": "419",
    "Apps": "88",
    "Quote_to_App_Conversion_Rate": "21",
    "Issued_Premium_USD": "0",
    "Agents_Using_Platform": "4640"
}, {
    "Launch_TimeFrame": "May-16",
    "Channel": "Group",
    "GSP": "Banca Gulf",
    "Program_to_Date": "235",
    "Quotes": "14",
    "Apps": "7",
    "Quote_to_App_Conversion_Rate": "50",
    "Issued_Premium_USD": "0",
    "Agents_Using_Platform": "40"
}]
};

// Now I will use the d3 object
d3.select("horizontalBar") // Selecting the body tag
  .append("h1") // I want to append an h1 for my chart title
  .text(dataset.title + ":"); // And I want to put my chart title in the h1

d3.select("#horizontalBar") // I am starting new chain for clarity... I want to reselect body so that I append to it (not the h1)
  .selectAll("div") // Selecting all divs because I want to bind data to them
  .data(dataset.data) // Just binding the 'data' values of dataset
  .enter() // Going to create the necessary divs based on dataset.data length
  .append("div") // Now I'm creating the div
  .transition()
  .duration(2000) // transition and 2s duration
  .style("width", function(d) { return d.Quote_to_App_Conversion_Rate * 20 + "px"; }) // Multiplying ProdIncidentsYT by 100 so I can get bigger bars
  .each("end", function(d) { //Once the bar transition ends, I want to transtion the bar legends opacity for each bar
    d3.select(this)
      .append("span")
      .text(d.GSP + ": " +  d.Quote_to_App_Conversion_Rate) // Creating the bar legend
      .transition()
      .style("opacity", 1); // Transitionaing opacity to 1
  });

  


////////////////////////////////////////////////////////////////////////////////





// Metric
$('.js-report-bar').each(function(sparklineId) {

  	var th = $(this),

        // Instead of splitting with "," we are passing the data in JSON format
        // Because splitting may cause getting datas as string
        // And that breaks scale calculators
        // Also this chain clears the HTML content
        data = [
   {
      "Launch_TimeFrame_info":"Jul-14",
      "Channel_info":"-",
      "GSvP":"US/Expat",
      "Register_info":"327",
      "Claims_info":"8617",
      "Docs_Forms":"698"
   },
   {
      "Launch_TimeFrame_info":"Nov-14",
      "Channel_info":"-",
      "GSvP":"China",
      "Register_info":"0",
      "Claims_info":"0",
      "Docs_Forms":"0"
   },
   {
      "Launch_TimeFrame_info":"Aug-13",
      "Channel_info":"-",
      "GSvP":"Turkey",
      "Register_info":"0",
      "Claims_info":"0",
      "Docs_Forms":"0"
   },
   {
      "Launch_TimeFrame_info":"Aug-13",
      "Channel_info":"-",
      "GSvP":"Italy",
      "Register_info":"820",
      "Claims_info":"0",
      "Docs_Forms":"1461"
   }
]; 
  
var m = {top:30, right:120, bottom:30, left:120},
    w = $('.js-report-bar').width() - m.right - m.left,
    h = $('.js-report-bar').height() - m.top - m.bottom;

var format = d3.format(",.0f");

var x = d3.scale.linear().range([0, w]),
    y = d3.scale.ordinal().rangeRoundBands([0, h], 0.5);
console.log(w); 
var xAxis = d3.svg.axis().scale(x).orient("bottom").tickSize(-h, 0, 0).tickFormat(function(d, i){ return d+"%" }),
    yAxis = d3.svg.axis().scale(y).orient("left").tickSize(0,0,0);

var container = d3.select(this).append("div");
  
   
  
var svg = d3.select("div.js-report-bar").append("svg")
    .attr("width", w + m.right + m.left)
    .attr("height", h + m.top + m.bottom)
    .append("g")
    .attr("transform", "translate(" + m.left + "," + m.top + ")");

  
  
  

  // Parse numbers, and sort by Register_info.
  data.forEach(function(d) { d.Register_info = +d.Register_info; });
  //data.sort(function(a, b) { return b.Register_info - a.Register_info; });

  
  // Set the scale domain.
  x.domain([0, d3.max(data, function(d) { return d.Register_info; })]);
  y.domain(data.map(function(d) { return d.GSvP; }));
  
  data.forEach(function(d,i) {
   
      var tooltip = container
          .append("div")
          .attr("class", "chart-tooltip")
          .attr("data-index", i).html(d.Register_info+"%");

      $tooltip = $(".chart-tooltip[data-index="+i+"]");
      
      var tooltipLeft = (m.left+x(d.Register_info)) - ($tooltip.width() / 2);
      var tooltipTop = (m.top+(y.rangeBand()*2)*i);

      $tooltip.css({
          left: tooltipLeft,
          top: tooltipTop 
      });
    
  }); 
  
  
  xAxisEl = svg.append("g")
      .attr("class", "x-axis")
      .attr("transform", "translate(" + 0 + "," + (h) + ")")
      .attr("stroke", "white")
      .call(xAxis);
  
  xAxisEl.selectAll("line").style("stroke-dasharray", ("3, 3"));
    
  xAxisEl.selectAll("text").attr("dy", "15");
  
  yAxisEl = svg.append("g")
      .attr("class", "y-axis")
      .call(yAxis);
  
  yAxisEl.selectAll("text").attr("dx", "-5");

  
  var bar = svg.selectAll("g.bar")
      .data(data)
    .enter().append("g")
      .attr("class", "bar")
      .attr("transform", function(d) { return "translate(0," + y(d.GSvP) + ")";  })
      .on("mouseenter", function(d, i) {
         console.log("Hovered over "+d.GSvP);
         $('.chart-tooltip[data-index='+i+']').addClass('hover');
      }).on("mouseleave", function(d, i) {
         $('.chart-tooltip.hover').removeClass('hover'); 
      });;

  var barColor = function(d){
    if(d.Register_info == 100) { 
      return "#a5d36e" 
    } else if(d.Register_info > 15) { 
      return "#59d1ba" 
    } else if(d.Register_info > 5) { 
      return "#fcd56b" 
    } else if(d.Register_info <= 5) { 
      return "#e86e6b" 
    }
  };
  
  bar.append("rect")
      .attr("width", function(d) { return x(d.Register_info); })
      .attr("height", y.rangeBand())
      .attr("fill", barColor)
      .attr("rx", 3)
      .attr("ry", 3);


  bar.append("text")
      .attr("class", "Register_info")
      .attr("x", function(d) { return x(d.Register_info); })
      .attr("y", y.rangeBand() / 2)
      .attr("dx", -5)
      .attr("dy", ".25em")
      .attr("text-anchor", "end")
      .attr("fill", "white")
      .text(function(d) { return (d.Register_info > 4) ? format(d.Register_info)+"%" : ""; });



});
